#pragma once

#include "types.h"

namespace sead {

class AudioRmtSpeakerMgrCafe { };

//static_assert(sizeof(AudioRmtSpeakerMgrCafe) == 0x24, "sead::AudioRmtSpeakerMgrCafe size mismatch");

}
