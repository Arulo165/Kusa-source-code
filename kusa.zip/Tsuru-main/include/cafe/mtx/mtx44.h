#pragma once

#include <dynamic_libs/mtxVec_functions.h>
