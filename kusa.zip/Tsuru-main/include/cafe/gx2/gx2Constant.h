#pragma once

#include <cafe/gx2.h>
