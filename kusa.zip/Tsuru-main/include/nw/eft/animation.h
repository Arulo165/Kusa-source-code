#pragma once

#include "types.h"

namespace nw { namespace eft {

struct KeyFrameAnim;

f32 CalcAnimKeyFrame(KeyFrameAnim* anim, f32 frame);

} }
