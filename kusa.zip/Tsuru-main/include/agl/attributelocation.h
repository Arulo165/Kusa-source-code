#pragma once

#include "agl/shaderprogram.h"

namespace agl {

class AttributeLocation {
public:
    void search(const ShaderProgram& program);
};

}
