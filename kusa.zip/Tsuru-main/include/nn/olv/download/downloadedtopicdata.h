#pragma once

namespace nn { namespace olv {

class DownloadedTopicData {
public:
    DownloadedTopicData();
};

} }
