#pragma once

#include "sead/task.h"

class ErrorViewerTask : public sead::CalculateTask {
    SEAD_SINGLETON_TASK(ErrorViewerTask);

public:
};
