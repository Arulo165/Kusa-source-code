#pragma once

#include "sead/task.h"

class DRCModeTask : public sead::CalculateTask {
    SEAD_SINGLETON_TASK(DRCModeTask);

public:
};
