#pragma once

#include "sead/task.h"

class ApplicationTask : public sead::CalculateTask {
    SEAD_SINGLETON_TASK(ApplicationTask);

public:
};
