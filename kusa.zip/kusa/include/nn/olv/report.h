#pragma once

#include "nn/types.h"

namespace nn { namespace olv {

class Report {
public:
    Result SetReportTypes(u32 flags);
};

} }
