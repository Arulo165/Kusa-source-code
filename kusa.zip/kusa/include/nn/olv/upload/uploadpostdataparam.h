#pragma once

#include "nn/types.h"
#include "types.h"

namespace nn { namespace olv {

class UploadPostDataParam {
public:
    Result SetCommunityId(const u32 communityID);
};

} }
