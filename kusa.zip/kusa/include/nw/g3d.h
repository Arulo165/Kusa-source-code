#pragma once

#include "nw/g3d/res/rescommon.h"
#include "nw/g3d/res/resfile.h"
#include "nw/g3d/shapeobj.h"
