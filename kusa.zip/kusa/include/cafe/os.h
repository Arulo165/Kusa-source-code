#pragma once

#include <types.h>

#include <dynamic_libs/os_functions.h>

#include <cafe/os/OSFastCast.h>
