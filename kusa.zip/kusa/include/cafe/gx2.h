#pragma once

#include <cafe/os.h>

#include <dynamic_libs/gx2_functions.h>
