#pragma once

namespace agl { namespace lyr {

enum DisplayType {
    DisplayType_TopTV,
    DisplayType_BottomDRC,
    DisplayType_Num,
    DisplayType_Invalid = 0xFFFFFFFF
};

} }
